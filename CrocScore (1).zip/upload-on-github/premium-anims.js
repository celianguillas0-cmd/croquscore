/* ─────────────────────────────────────────────────────────────────
   CrocScore — App Shell controller
   Transforme la home en app + injecte le bouton scan central +
   anime tous les clics.
   ─────────────────────────────────────────────────────────────── */
(function() {
  'use strict';

  function ready(fn) {
    if (document.readyState !== 'loading') fn();
    else document.addEventListener('DOMContentLoaded', fn);
  }

  ready(function init() {
    injectScanFab();
    enhanceHero();
    addHomeChips();
    setupRipple();
    setupSparkles();
    setupHeroLinks();
  });

  /* ───── 1. Inject central scan FAB into the bottom nav ────────── */
  function injectScanFab() {
    var nav = document.querySelector('.bottom-nav');
    if (!nav || nav.querySelector('.cs-scan-fab')) return;

    var fab = document.createElement('button');
    fab.className = 'cs-scan-fab';
    fab.setAttribute('aria-label', 'Scanner un produit');
    fab.innerHTML = '<svg width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 8V6a2 2 0 0 1 2-2h2"/><path d="M16 4h2a2 2 0 0 1 2 2v2"/><path d="M20 16v2a2 2 0 0 1-2 2h-2"/><path d="M8 20H6a2 2 0 0 1-2-2v-2"/><path d="M4 12h16"/></svg>';
    fab.addEventListener('click', function() {
      if (typeof openScan === 'function') openScan();
    });

    // Insert in middle of nav (after 3rd item, before 4th)
    var items = nav.querySelectorAll('.bn-item');
    if (items.length >= 4) {
      nav.insertBefore(fab, items[Math.floor(items.length / 2)]);
    } else {
      nav.appendChild(fab);
    }

    // Reduce visible items if there are too many (keep 4-5 max)
    items = nav.querySelectorAll('.bn-item');
    if (items.length > 5) {
      // Hide the least essential ones (alertes if present)
      var alertes = nav.querySelector('#bn-alertes');
      if (alertes) alertes.style.display = 'none';
    }
  }

  /* ───── 2. Enhance hero: word reveal + better content ─────────── */
  function enhanceHero() {
    var h1 = document.querySelector('.hero h1');
    if (h1 && !h1.dataset.csEnhanced) {
      h1.dataset.csEnhanced = '1';
      var counter = { i: 0 };
      walkAndWrap(h1, counter);
    }
  }

  function walkAndWrap(node, counter) {
    var children = Array.prototype.slice.call(node.childNodes);
    children.forEach(function(child) {
      if (child.nodeType === 3) {
        var text = child.nodeValue;
        if (!text || !text.trim()) return;
        var parts = text.split(/(\s+)/);
        var frag = document.createDocumentFragment();
        parts.forEach(function(p) {
          if (!p) return;
          if (/^\s+$/.test(p)) {
            frag.appendChild(document.createTextNode(p));
          } else {
            var span = document.createElement('span');
            span.className = 'cs-word';
            span.style.setProperty('--w', counter.i++);
            span.textContent = p;
            frag.appendChild(span);
          }
        });
        node.replaceChild(frag, child);
      } else if (child.nodeType === 1) {
        walkAndWrap(child, counter);
      }
    });
  }

  /* ───── 3. Add home quick-action chips ────────────────────────── */
  function addHomeChips() {
    var hero = document.querySelector('.hero > div:first-child');
    if (!hero || hero.querySelector('.cs-home-chips')) return;

    var chipsHTML = ''
      + '<div class="cs-home-chips">'
      +   '<button class="cs-home-chip" onclick="openAnalyserPanel()">'
      +     '<div class="cs-home-chip-icon"><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg></div>'
      +     '<div class="cs-home-chip-title">Analyser</div>'
      +     '<div class="cs-home-chip-sub">Recherchez parmi 14 000 produits</div>'
      +   '</button>'
      +   '<button class="cs-home-chip" onclick="openStatsPanel()">'
      +     '<div class="cs-home-chip-icon"><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><line x1="18" y1="20" x2="18" y2="10"/><line x1="12" y1="20" x2="12" y2="4"/><line x1="6" y1="20" x2="6" y2="14"/></svg></div>'
      +     '<div class="cs-home-chip-title">Statistiques</div>'
      +     '<div class="cs-home-chip-sub">Suivi nutritionnel de votre animal</div>'
      +   '</button>'
      +   '<button class="cs-home-chip" onclick="openAlertModal && openAlertModal()">'
      +     '<div class="cs-home-chip-icon"><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"/><path d="M13.73 21a2 2 0 0 1-3.46 0"/></svg></div>'
      +     '<div class="cs-home-chip-title">Alertes</div>'
      +     '<div class="cs-home-chip-sub">Soyez prévenu des additifs sensibles</div>'
      +   '</button>'
      +   '<button class="cs-home-chip" onclick="openAuth()">'
      +     '<div class="cs-home-chip-icon"><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg></div>'
      +     '<div class="cs-home-chip-title">Mon compte</div>'
      +     '<div class="cs-home-chip-sub">Synchronisez vos données animal</div>'
      +   '</button>'
      + '</div>'
      + '<div class="cs-home-premium" onclick="openPremModal()">'
      +   '<span class="cs-home-premium-pill">'
      +     '<svg width="11" height="11" viewBox="0 0 24 24" fill="currentColor"><path d="M12 2L9 9 2 9.5l5.5 4.5L6 22l6-4 6 4-1.5-8L22 9.5 15 9z"/></svg>'
      +     'Premium'
      +   '</span>'
      +   '<div class="cs-home-premium-title">Suivez l\u2019évolution de <em>votre animal</em>.</div>'
      +   '<div class="cs-home-premium-sub">Résumé mensuel, alertes additifs, rapport PDF vétérinaire.</div>'
      +   '<button class="cs-home-premium-btn" onclick="event.stopPropagation();openPremModal()">Découvrir Premium <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"><path d="M5 12h14M13 6l6 6-6 6"/></svg></button>'
      + '</div>'
      + '<div class="cs-home-disclaimer">'
      +   '<svg class="cs-home-disclaimer-icon" width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="9"/><path d="M12 11v6M12 8h.01"/></svg>'
      +   '<span>Scores indicatifs basés sur la composition des produits. CrocScore ne remplace pas l\u2019avis d\u2019un vétérinaire.</span>'
      + '</div>';

    var wrap = document.createElement('div');
    wrap.innerHTML = chipsHTML;
    while (wrap.firstChild) hero.appendChild(wrap.firstChild);
  }

  /* ───── 4. Ripple effect on click ─────────────────────────────── */
  function setupRipple() {
    var selectors = [
      '.nav-cta', '.cta-btn', '.showcase-cta-btn',
      '.hero-search button', '.showcase-search button',
      '.plan-btn', '.auth-btn',
      '.bn-item', '.cs-scan-fab',
      '.cs-home-chip', '.cs-home-premium-btn',
      '.account-item', '.hero-scan',
    ];
    document.addEventListener('click', function(e) {
      var target = null;
      for (var i = 0; i < selectors.length; i++) {
        var t = e.target.closest(selectors[i]);
        if (t) { target = t; break; }
      }
      if (!target) return;

      var rect = target.getBoundingClientRect();
      var cs = getComputedStyle(target);
      if (cs.position === 'static') target.style.position = 'relative';
      if (cs.overflow !== 'hidden') target.style.overflow = 'hidden';

      var ripple = document.createElement('span');
      ripple.className = 'cs-ripple';
      var size = Math.max(rect.width, rect.height) * 1.4;
      ripple.style.width = ripple.style.height = size + 'px';
      ripple.style.left = (e.clientX - rect.left - size / 2) + 'px';
      ripple.style.top = (e.clientY - rect.top - size / 2) + 'px';
      target.appendChild(ripple);
      setTimeout(function() {
        if (ripple.parentNode) ripple.parentNode.removeChild(ripple);
      }, 700);
    }, { passive: true });
  }

  /* ───── 5. Sparkles on premium sections ───────────────────────── */
  function setupSparkles() {
    function decorate(host, count) {
      if (host.dataset.csSparkles) return;
      host.dataset.csSparkles = '1';
      for (var i = 0; i < count; i++) {
        var s = document.createElement('div');
        s.className = 'cs-sparkle';
        s.style.top = (8 + Math.random() * 84) + '%';
        s.style.left = (5 + Math.random() * 90) + '%';
        s.style.animationDelay = (i * 0.4 + Math.random() * 0.5) + 's';
        s.style.animationDuration = (2 + Math.random() * 2) + 's';
        host.appendChild(s);
      }
    }
    document.querySelectorAll('.cs-home-premium, .account-plan-card.premium').forEach(function(el) {
      decorate(el, 7);
    });
  }

  /* ───── 6. Hero existing "hero-scan" link should call openScan ── */
  function setupHeroLinks() {
    var heroScan = document.querySelector('.hero-scan');
    if (heroScan && !heroScan.dataset.csHandler) {
      heroScan.dataset.csHandler = '1';
      // openScan already wired via existing onclick — no-op
    }
  }
})();
