/* ─────────────────────────────────────────────────────────────────
   CrocScore — Premium animations (interactive layer)
   Pure additif — n'override aucune fonction existante.
   Auto-init au DOMContentLoaded.
   ─────────────────────────────────────────────────────────────── */
(function() {
  'use strict';

  function ready(fn) {
    if (document.readyState !== 'loading') fn();
    else document.addEventListener('DOMContentLoaded', fn);
  }

  ready(function init() {
    enhanceHeroTitle();
    setupScrollReveal();
    setupRipple();
    setupCounters();
    setupSparkles();
  });

  /* ───── 1. Word reveal sur le titre du hero ───────────────────── */
  function enhanceHeroTitle() {
    var h1 = document.querySelector('.hero h1');
    if (!h1 || h1.dataset.csEnhanced) return;
    h1.dataset.csEnhanced = '1';

    // Walk text nodes and wrap each word in a <span class="cs-word">
    var wordCounter = { i: 0 };
    walkAndWrap(h1, wordCounter);
  }

  function walkAndWrap(node, counter) {
    var i = 0;
    var children = Array.prototype.slice.call(node.childNodes);
    children.forEach(function(child) {
      if (child.nodeType === 3) { // text node
        var text = child.nodeValue;
        if (!text || !text.trim()) return;
        var parts = text.split(/(\s+)/);
        var frag = document.createDocumentFragment();
        parts.forEach(function(p) {
          if (!p) return;
          if (/^\s+$/.test(p)) {
            frag.appendChild(document.createTextNode(p));
          } else {
            var span = document.createElement('span');
            span.className = 'cs-word';
            span.style.setProperty('--w', counter.i++);
            span.textContent = p;
            frag.appendChild(span);
          }
        });
        node.replaceChild(frag, child);
      } else if (child.nodeType === 1) {
        walkAndWrap(child, counter);
      }
    });
  }

  /* ───── 2. Scroll reveal (sections + cards) ───────────────────── */
  function setupScrollReveal() {
    if (!('IntersectionObserver' in window)) return;

    // Targets : sections clés + cards
    var selectors = [
      '.showcase-top',
      '.sc-feat',
      '.hero-card-main',
      '.how-step',
      '.score-card',
      '.why-card',
      '.feature-block',
      '.suivi-stat-card',
      '.suivi-mock-card',
      '.plan',
      '.cta-inner > *',
    ];

    var els = document.querySelectorAll(selectors.join(', '));
    var groups = {};
    els.forEach(function(el) {
      if (el.dataset.csReveal) return;
      el.dataset.csReveal = '1';
      el.classList.add('cs-reveal');

      // Stagger : compute delay based on position within parent
      var parent = el.parentElement;
      var key = parent ? parent.tagName + (parent.id || parent.className || '') : 'root';
      groups[key] = (groups[key] || 0) + 1;
      var idx = Math.min(groups[key], 4);
      el.setAttribute('data-cs-delay', idx);
    });

    var io = new IntersectionObserver(function(entries) {
      entries.forEach(function(entry) {
        if (entry.isIntersecting) {
          entry.target.classList.add('is-visible');
          io.unobserve(entry.target);
        }
      });
    }, { rootMargin: '0px 0px -8% 0px', threshold: 0.05 });

    els.forEach(function(el) { io.observe(el); });
  }

  /* ───── 3. Ripple effect sur les boutons ──────────────────────── */
  function setupRipple() {
    var selectors = [
      '.nav-cta', '.cta-btn', '.showcase-cta-btn',
      '.hero-search button', '.showcase-search button',
      '.plan-btn', '.auth-btn',
      '.score-card', '.sc-feat', '.how-step',
      '.bn-item', '.account-item',
    ];
    document.addEventListener('click', function(e) {
      var target = null;
      for (var i = 0; i < selectors.length; i++) {
        var t = e.target.closest(selectors[i]);
        if (t) { target = t; break; }
      }
      if (!target) return;

      var rect = target.getBoundingClientRect();
      // Ensure relative positioning + overflow hidden
      var cs = getComputedStyle(target);
      if (cs.position === 'static') target.style.position = 'relative';
      if (cs.overflow !== 'hidden') target.style.overflow = 'hidden';

      var ripple = document.createElement('span');
      ripple.className = 'cs-ripple';
      var size = Math.max(rect.width, rect.height) * 1.4;
      ripple.style.width = ripple.style.height = size + 'px';
      ripple.style.left = (e.clientX - rect.left - size / 2) + 'px';
      ripple.style.top = (e.clientY - rect.top - size / 2) + 'px';
      target.appendChild(ripple);
      setTimeout(function() {
        if (ripple.parentNode) ripple.parentNode.removeChild(ripple);
      }, 700);
    }, { passive: true });
  }

  /* ───── 4. Number counter sur visibilité ──────────────────────── */
  function setupCounters() {
    if (!('IntersectionObserver' in window)) return;

    // Targets : stats avec data-cs-count="N" ou numbers visibles
    var candidates = [];
    var selectors = ['.hero-stat-num', '.suivi-stat-num', '.why-stat-num',
                     '[data-cs-count]'];
    selectors.forEach(function(sel) {
      document.querySelectorAll(sel).forEach(function(el) {
        if (el.dataset.csCountInit) return;
        var raw = (el.getAttribute('data-cs-count') || el.textContent || '').trim();
        var match = raw.match(/(\d[\d\s]*)/);
        if (!match) return;
        var num = parseInt(match[1].replace(/\s/g, ''), 10);
        if (!num || num > 99999) return;
        el.dataset.csCountInit = '1';
        el.dataset.csCountTarget = num;
        el.dataset.csCountSuffix = raw.replace(match[1], '').trim();
        el.textContent = '0' + (el.dataset.csCountSuffix ? ' ' + el.dataset.csCountSuffix : '');
        candidates.push(el);
      });
    });

    var io = new IntersectionObserver(function(entries) {
      entries.forEach(function(entry) {
        if (!entry.isIntersecting) return;
        animateCount(entry.target);
        io.unobserve(entry.target);
      });
    }, { threshold: 0.4 });
    candidates.forEach(function(el) { io.observe(el); });
  }

  function animateCount(el) {
    var target = parseInt(el.dataset.csCountTarget, 10);
    var suffix = el.dataset.csCountSuffix || '';
    var duration = 1400;
    var start = performance.now();
    function tick(t) {
      var p = Math.min(1, (t - start) / duration);
      var eased = 1 - Math.pow(1 - p, 3);
      var val = Math.round(target * eased);
      el.textContent = val.toLocaleString('fr-FR') + (suffix ? ' ' + suffix : '');
      if (p < 1) requestAnimationFrame(tick);
    }
    requestAnimationFrame(tick);
  }

  /* ───── 5. Sparkles décoratifs sur sections premium ───────────── */
  function setupSparkles() {
    var hosts = document.querySelectorAll(
      '.suivi-section, .plan.premium, .account-plan-card.premium'
    );
    hosts.forEach(function(host) {
      if (host.dataset.csSparkles) return;
      host.dataset.csSparkles = '1';
      var count = 6;
      for (var i = 0; i < count; i++) {
        var s = document.createElement('div');
        s.className = 'cs-sparkle';
        s.style.top = (8 + Math.random() * 84) + '%';
        s.style.left = (5 + Math.random() * 90) + '%';
        s.style.animationDelay = (i * 0.4 + Math.random() * 0.5) + 's';
        s.style.animationDuration = (2 + Math.random() * 2) + 's';
        host.appendChild(s);
      }
    });
  }
})();
